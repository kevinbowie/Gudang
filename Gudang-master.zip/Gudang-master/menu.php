<!DOCTYPE html>
<html>
<head>
	<title>MENU GUDANG</title>
</head>
<body>
	<a href="master_customer.php">TAMBAH ID CUSTOMER</a>
	<a href="master_stok.php">TAMBAH JENIS BARANG</a>
	<a href="pembelian.php">INPUT PEMBELIAN</a>
	<a href="penjualan.php">INPUT PENJUALAN</a>
	<a href="laporan_stok.php">LAPORAN STOK</a>
	<br>
	<a href="logout.php">LOGOUT</a>
</body>
</html>